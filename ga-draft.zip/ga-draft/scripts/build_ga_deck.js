#!/usr/bin/env node
/*
 * build_ga_deck.js — Graphical abstract 시안 덱 만들기
 *
 *   node build_ga_deck.js spec.json out.pptx             시안 비교 덱 (16:9: 한눈에 보기 1장 + 시안마다 1장)
 *   node build_ga_deck.js spec.json out.pptx --final B   고른 시안만 캔버스 크기 그대로 (작업 파일)
 *
 * 캔버스 좌표: 높이 100, 폭 100 × aspect. 글자 크기는 캔버스 높이 8인치 기준 24/20/16pt
 * (= 4인치(1200px, 300dpi)로 줄였을 때 12/10/8pt, Cell Press 권장 범위).
 * 그림 자리는 회색 점선 칸("IMG ..." 이름)으로 비워 둔다. 그림은 사람이 고른 뒤에 채운다.
 */
const fs = require('fs');
const PptxGenJS = require('pptxgenjs');

const FONT = 'Arial';
const INK = '111827', GRAY = '4B5563', MUTE = '6B7280';
// illustrated(기본): 그림이 주인공. 남색 글자 · 굵은 남색 화살표 · 테두리 없는 그림 · 색 면 패널
const ILL = { ink: '1F2A44', arrow: '3A4660' };
const PH_FILL = 'EEF1F5', PH_LINE = '98A2B3', FRAME = 'D0D5DD';
const PALETTE = {
  a: { accent: '1F5FA8', tint: 'E4EEF9' },   // 파랑: 개입 · 정상 · 주인공
  b: { accent: 'C2410C', tint: 'FCEBE3' },   // 주황빨강: 질환 · 대조 (적록 조합을 피함)
  n: { accent: '4B5563', tint: 'F1F3F6' },   // 회색: 중립
};
const BASE_PT = { L: 24, M: 20, S: 16 };
const MIN_PT = 13;                            // 8인치 캔버스 기준 하한 (4인치에서 6.5pt)
const STYLE_PREFIX = 'flat vector scientific illustration, simple shapes, clean outlines, soft muted colors, '
  + 'pure white background, single subject centered, no text, no labels, no arrows';
const LAYOUT_NAME = {
  ko: { flow: '한 줄 흐름', compare: '나란히 비교', zoom: '확대', hub: '가운데형' },
  en: { flow: 'Flow', compare: 'Comparison', zoom: 'Zoom-in', hub: 'Hub' },
};
const T = {
  ko: { title: 'Figure 시안', msg: '핵심 문장', why: '왜 이 구도', imgs: '그림 자리', left: '뺀 것',
        bound: '주의 (과장 금지)', opt: '시안',
        foot: '회색 칸 = 그림 자리 · 글자와 화살표는 PPT에서 바로 수정 · 생성한 이미지는 초안용 (투고 전 저널 규정 확인)' },
  en: { title: 'Figure options', msg: 'Key message', why: 'Why this layout', imgs: 'Image slots', left: 'Left out',
        bound: 'Claim boundary', opt: 'Option',
        foot: 'Dashed gray boxes = image slots · edit text and arrows directly in PowerPoint · AI images are for drafts only (check the journal AI policy)' },
};

// ---------- 글자 폭 어림 ----------
function vlen(s) { let n = 0; for (const ch of String(s)) n += /[ᄀ-ᇿ　-鿿가-힯＀-￯]/.test(ch) ? 1.9 : 1; return n; }
function countLines(text, wIn, pt, bold, strict) {
  const cpl = Math.max(1, (wIn * 72) / ((bold ? 0.58 : 0.53) * pt));
  let n = 0;
  for (const para of String(text).split('\n')) {
    n++; let cur = 0;
    for (const w of para.split(/\s+/).filter(Boolean)) {
      const L = vlen(w);
      if (strict && L > cpl) return 999;
      if (cur === 0) cur = L; else if (cur + 1 + L <= cpl) { cur += 1 + L; continue; } else { n++; cur = L; }
      while (cur > cpl) { n++; cur -= cpl; }
    }
  }
  return n;
}
function fitPt(text, wIn, hIn, pt, minPt, bold) {
  const need = (q, strict) => (countLines(text, wIn, q, bold, strict) * q * 1.18) / 72;
  let p = pt; while (p > minPt && need(p, true) > hIn) p -= 0.5;
  return { pt: p, ok: need(p, true) <= hIn + 0.02 };
}
// 그림 자리 안의 설명: 안 들어가면 뒤 낱말을 줄이고 … 를 붙인다 (전체 이름은 도형 이름과 슬라이드 노트에 남는다)
function fitHint(name, wIn, hIn, pt, minPt) {
  let t = String(name), f = fitPt(t, wIn, hIn, pt, minPt, false);
  const ws = t.split(/\s+/);
  while (!f.ok && ws.length > 1) { ws.pop(); t = ws.join(' ') + '…'; f = fitPt(t, wIn, hIn, pt, minPt, false); }
  return { text: t, pt: f.pt };
}
const words = (s) => String(s || '').replace(/[↑↓→]/g, ' ').split(/\s+/).filter((w) => /[A-Za-z0-9가-힣]/.test(w)).length;

// ---------- 링크(화살표) ----------
// "label" 일반 화살표 · "-| label" 억제 · "~ label" 점선(연관, 인과 아님) · {label, kind}
function normLink(l) {
  if (!l) return { label: '', kind: 'arrow' };
  if (typeof l === 'object') return { label: l.label || '', kind: l.kind || 'arrow' };
  const s = String(l).trim();
  if (s.startsWith('-|')) return { label: s.slice(2).trim(), kind: 'inhibit' };
  if (s.startsWith('~')) return { label: s.slice(1).trim(), kind: 'dashed' };
  return { label: s, kind: 'arrow' };
}

// ---------- 프리미티브 ----------
function mk(W, H, pal, context, files, style) { return { W, H, pal, context, files: files || {}, style: style || 'illustrated', prims: [], images: [], wc: 0 }; }
function img(c, x, y, s, item, o = {}) {
  const name = item.image || item.label;
  c.prims.push({ t: 'img', x, y, w: s, h: s, name, accent: o.accent, tone: o.tone, round: o.round });
  c.images.push({ name, label: item.label || '' });
}
function txt(c, x, y, w, h, text, o = {}) {
  if (!text) return;
  if (o.count !== false) c.wc += words(text);
  c.prims.push(Object.assign({ t: 'text', x, y, w, h, text, size: 'M', align: 'center', valign: 'top' }, o));
}
function arr(c, x1, y1, x2, y2, link = {}, o = {}) { c.prims.push({ t: 'arrow', x1, y1, x2, y2, kind: link.kind || 'arrow', color: o.color, heavy: o.heavy }); }
function panel(c, x, y, w, h, o = {}) { c.prims.push(Object.assign({ t: 'panel', x, y, w, h }, o)); }

// ---------- 틀 1: 흐름형 (한 줄, 5개 이상이면 U자 두 줄) ----------
function layoutFlow(c, d) {
  const { W, H } = c, m = 5; let top = m, bottom = H - m;
  if (d.headline) { txt(c, m, top, W - 2 * m, 9, d.headline, { size: 'L', bold: true, valign: 'middle' }); top += 11; }
  if (c.context) bottom -= 8;
  const steps = d.steps, n = steps.length, links = (d.links || []).map(normLink);
  const hasLbl = links.some((l) => l.label), gap = hasLbl ? 16 : 9, labelH = 14;
  const out = d.outcome_index === undefined ? n - 1 : d.outcome_index;
  const s1 = Math.min(30, (W - 2 * m - (n - 1) * gap) / n);
  const r1 = Math.ceil(n / 2), r2 = n - r1, vg = 8;
  const s2 = Math.min(26, (W - 2 * m - (r1 - 1) * gap) / r1, (bottom - top - vg - 2 * (2 + labelH)) / 2);
  const oneRow = n <= 3 || s1 >= 18 || s1 >= s2;
  const place = (i, x, y, s) => {
    img(c, x, y, s, steps[i], { accent: i === out, tone: 'a' });
    txt(c, x - gap / 2 + 0.8, y + s + 2, s + gap - 1.6, labelH, steps[i].label, { bold: true, color: i === out ? c.pal.a.accent : INK });
  };
  const linkLabel = (l, xa, xb, y) => { if (l && l.label) txt(c, Math.min(xa, xb) + 0.4, y - 11.5, Math.abs(xb - xa) - 0.8, 10, l.label, { size: 'S', color: GRAY, valign: 'bottom' }); };
  if (oneRow) {
    const s = s1, total = n * s + (n - 1) * gap;
    const x0 = (W - total) / 2, y = top + (bottom - top - (s + 2 + labelH)) / 2;
    for (let i = 0; i < n; i++) {
      const x = x0 + i * (s + gap); place(i, x, y, s);
      if (i < n - 1) { const l = links[i] || {}; arr(c, x + s + 1.4, y + s / 2, x + s + gap - 1.4, y + s / 2, l); linkLabel(l, x + s, x + s + gap, y + s / 2); }
    }
  } else {
    const s = s2;
    const blockH = s + 2 + labelH, total = r1 * s + (r1 - 1) * gap, x0 = (W - total) / 2;
    const y1 = top + (bottom - top - (2 * blockH + vg)) / 2, y2 = y1 + blockH + vg;
    const col = (k) => x0 + k * (s + gap);
    for (let i = 0; i < r1; i++) {
      place(i, col(i), y1, s);
      if (i < r1 - 1) { const l = links[i] || {}; arr(c, col(i) + s + 1.4, y1 + s / 2, col(i + 1) - 1.4, y1 + s / 2, l); linkLabel(l, col(i) + s, col(i + 1), y1 + s / 2); }
    }
    const xc = col(r1 - 1) + s / 2; arr(c, xc, y1 + blockH + 0.8, xc, y2 - 1.2, links[r1 - 1] || {});
    for (let j = 0; j < r2; j++) {
      const k = r1 - 1 - j, i = r1 + j; place(i, col(k), y2, s);
      if (j < r2 - 1) { const l = links[i] || {}; arr(c, col(k) - 1.4, y2 + s / 2, col(k - 1) + s + 1.4, y2 + s / 2, l); linkLabel(l, col(k - 1) + s, col(k), y2 + s / 2); }
    }
  }
}

// ---------- 틀 2: 비교형 (같은 칸을 나란히, 다른 곳만 다르게) ----------
function layoutCompare(c, d) {
  const { W, H } = c, m = 4; let top = m, bottom = H - m;
  if (d.headline) { txt(c, m, top, W - 2 * m, 8, d.headline, { size: 'L', bold: true, valign: 'middle' }); top += 10; }
  if (c.context) bottom -= 8;
  const ill = c.style !== 'clean';
  const cols = d.columns, nc = cols.length, cg = ill ? 0 : 3, cw = (W - 2 * m - (nc - 1) * cg) / nc;
  const colX = (i) => m + i * (cw + cg);
  if (d.shared) {
    const s = ill ? 13 : 12, lw = Math.min(40, W * 0.4), gx = (W - (s + 2 + lw)) / 2;
    img(c, gx, top, s, d.shared, { tone: 'n' });
    txt(c, gx + s + 2, top, lw, s, d.shared.label, { bold: true, align: 'left', valign: 'middle' });
    const ya = top + s + 1, yb = top + s + 5.2;
    for (let i = 0; i < nc; i++) arr(c, W / 2 + (i - (nc - 1) / 2) * 6, ya, colX(i) + cw / 2, yb, {}, { color: GRAY });
    top += s + (ill ? 5.5 : 6.5);
  }
  const ph = bottom - top, headH = ill ? 7 : 8, outH = ill ? 9 : 10, pad = 3;
  cols.forEach((col, i) => {
    const tone = col.tone || (i === 0 ? 'b' : 'a'), P = c.pal[tone] || c.pal.n, x = colX(i);
    panel(c, x, top, cw, ph, { fill: P.tint, square: ill });
    txt(c, x + (ill ? pad : 2), top + 1.5, cw - (ill ? 2 * pad : 4), headH, col.title, { bold: true, color: ill ? INK : P.accent, align: ill ? 'left' : 'center', valign: 'middle' });
    const k = col.steps.length, yS = top + 1.5 + headH + 1.5, yO = top + ph - pad - outH;
    const pitch = (yO - yS) / k, s = Math.min(ill ? 24 : 17, pitch - 5, cw * (ill ? 0.44 : 0.38)), links = (col.links || []).map(normLink);
    col.steps.forEach((st, r) => {
      const yy = yS + r * pitch;
      img(c, x + pad, yy, s, st, { tone });
      txt(c, x + pad + s + 2, yy, cw - 2 * pad - s - 2, s, st.label, { bold: !!st.diff, align: 'left', valign: 'middle' });
      const yn = r < k - 1 ? yS + (r + 1) * pitch : yO;
      arr(c, x + pad + s / 2, yy + s + 0.9, x + pad + s / 2, yn - 0.9, links[r] || {}, { color: ill ? undefined : P.accent });
    });
    c.prims.push({ t: 'chip', x: x + pad, y: yO, w: cw - 2 * pad, h: outH, text: col.outcome, fill: P.accent, soft: ill });
    c.wc += words(col.outcome);
  });
}

// ---------- 틀 3: 확대형 (위: 현상 한 줄, 아래: 확대한 기전) ----------
function layoutZoom(c, d) {
  const { W, H } = c, m = 5; let top = m, bottom = H - m;
  if (c.context) bottom -= 8;
  const row = d.levels.map((x) => Object.assign({}, x)); const src = row.length - 1;
  if (d.outcome) row.push(Object.assign({ isOut: true }, d.outcome));
  const n = row.length, labelH = 10, s = Math.min(24, (W - 2 * m - (n - 1) * 12) / n);
  let gap = n > 1 ? (W - 2 * m - n * s) / (n - 1) : 0; gap = Math.min(gap, 30);
  const x0 = (W - (n * s + (n - 1) * gap)) / 2, tl = (d.top_links || []).map(normLink);
  const py = top + s + 2 + labelH + 5, ph = bottom - py, px = m, pw = W - 2 * m;
  const sx = x0 + src * (s + gap) + s * 0.3, sy = top + s * 0.3, sw = s * 0.4;
  c.prims.push({ t: 'cone', pts: [[sx, sy + sw], [sx + sw, sy + sw], [px + pw, py], [px, py]], fill: c.pal.a.tint });
  row.forEach((it, i) => {
    const x = x0 + i * (s + gap);
    img(c, x, top, s, it, { accent: !!it.isOut, tone: 'a' });
    txt(c, x - 4, top + s + 2, s + 8, labelH, it.label, { bold: true, color: it.isOut ? c.pal.a.accent : INK });
    if (i < n - 1) {
      const l = tl[i] || {}; arr(c, x + s + 1.4, top + s / 2, x + s + gap - 1.4, top + s / 2, l);
      if (l.label) txt(c, x + s + 0.4, top + s / 2 - 11.5, gap - 0.8, 10, l.label, { size: 'S', color: GRAY, valign: 'bottom' });
    }
  });
  c.prims.push({ t: 'frame', x: sx, y: sy, w: sw, h: sw, color: c.pal.a.accent });
  panel(c, px, py, pw, ph, { fill: 'FFFFFF', line: c.style !== 'clean' ? ILL.ink : c.pal.a.accent });
  const det = d.detail, items = det.items, k = items.length, links = (det.links || []).map(normLink);
  let iy = py + 3;
  if (det.title) { txt(c, px + 3, py + 2, pw - 6, 6.5, det.title, { size: 'S', bold: true, color: c.style !== 'clean' ? INK : c.pal.a.accent, align: 'left', valign: 'middle' }); iy = py + 10; }
  const il = 11, is = Math.min(20, py + ph - 2.5 - il - 2 - iy, (pw - 8 - (k - 1) * 12) / k);
  let ig = k > 1 ? (pw - 8 - k * is) / (k - 1) : 0; ig = Math.min(ig, 26);
  const ix0 = px + (pw - (k * is + (k - 1) * ig)) / 2, yy = iy + (py + ph - 2.5 - iy - (is + 2 + il)) / 2;
  items.forEach((it, i) => {
    const x = ix0 + i * (is + ig);
    img(c, x, yy, is, it, { tone: 'a' });
    const cx = x + is / 2, half = Math.min((is + ig - 1.6) / 2, cx - (px + 1.5), px + pw - 1.5 - cx);
    txt(c, cx - half, yy + is + 2, 2 * half, il, it.label, { bold: !!it.diff });
    if (i < k - 1) {
      const l = links[i] || {}; arr(c, x + is + 1.4, yy + is / 2, x + is + ig - 1.4, yy + is / 2, l);
      if (l.label) txt(c, x + is + 0.4, yy + is / 2 - 10.5, ig - 0.8, 9, l.label, { size: 'S', color: GRAY, valign: 'bottom' });
    }
  });
}

// ---------- 틀 4: 허브형 (여러 입력 → 한 인자 → 여러 결과) ----------
function layoutHub(c, d) {
  const { W, H } = c, m = 5; let top = m, bottom = H - m;
  if (d.headline) { txt(c, m, top, W - 2 * m, 9, d.headline, { size: 'L', bold: true, valign: 'middle' }); top += 11; }
  if (c.context) bottom -= 8;
  const avail = bottom - top, cs = Math.min(34, avail * 0.45, W * 0.34), cx = W / 2 - cs / 2, cy = top + (avail - cs - 12) / 2;
  img(c, cx, cy, cs, d.center, { accent: true, tone: 'a', round: true });
  txt(c, cx - 6, cy + cs + 2, cs + 12, 10, d.center.label, { size: 'L', bold: true, color: c.pal.a.accent });
  const side = (items, left) => {
    const k = items.length; if (!k) return;
    const lh = 10, s = Math.min(18, (avail - (k - 1) * 4) / k - lh - 2), block = s + 2 + lh, total = k * block + (k - 1) * 4;
    const x = left ? m + 3 : W - m - 3 - s, y0 = top + (avail - total) / 2;
    items.forEach((it, i) => {
      const y = y0 + i * (block + 4), l = normLink(it.link), ty = cy + cs / 2 + (i - (k - 1) / 2) * Math.min(8, cs / (k + 1));
      img(c, x, y, s, it, { tone: left ? 'n' : 'a' });
      txt(c, x - 7, y + s + 2, s + 14, lh, it.label, { bold: !left });
      if (left) arr(c, x + s + 1.4, y + s / 2, cx - 1.4, ty, l); else arr(c, cx + cs + 1.4, ty, x - 1.4, y + s / 2, l);
      if (l.label) { const xa = left ? x + s : cx + cs, xb = left ? cx : x; txt(c, xa + 0.5, (y + s / 2 + ty) / 2 - 9, xb - xa - 1, 8, l.label, { size: 'S', color: GRAY, valign: 'bottom' }); }
    });
  };
  side(d.inputs || [], true); side(d.outputs || [], false);
}

const LAYOUTS = { flow: layoutFlow, compare: layoutCompare, zoom: layoutZoom, hub: layoutHub };

function buildOption(opt, spec, pal) {
  const aspect = spec.aspect || 1, W = 100 * aspect, H = 100;
  const context = opt.content.context === undefined ? spec.context : opt.content.context;
  const c = mk(W, H, pal, context, spec.image_files, spec.style);
  LAYOUTS[opt.layout](c, opt.content);
  if (context) txt(c, 5, H - 5 - 6, W - 10, 6, context, { size: 'S', color: MUTE, valign: 'middle', count: false });
  return c;
}

// ---------- 그림 크기 (PNG · JPEG 머리만 읽음) ----------
function imgSize(file) {
  const b = fs.readFileSync(file);
  if (b.readUInt32BE(0) === 0x89504e47) return [b.readUInt32BE(16), b.readUInt32BE(20)];
  let i = 2; while (i < b.length) { const mk = b[i + 1], len = b.readUInt16BE(i + 2); if (mk >= 0xc0 && mk <= 0xc3) return [b.readUInt16BE(i + 7), b.readUInt16BE(i + 5)]; i += 2 + len; }
  return [1, 1];
}

// ---------- 그리기 ----------
function drawCanvas(pres, slide, c, ox, oy, hIn, warn, tag) {
  const ill = c.style !== 'clean', u = hIn / 100, k = hIn / 8, X = (v) => ox + v * u, Y = (v) => oy + v * u;
  const lw = Math.max(0.75, (ill ? 2.75 : 2) * k), inkOf = (col) => (ill && (!col || col === INK) ? ILL.ink : col || INK);
  let ii = 0;
  for (const p of c.prims) {
    if (p.t === 'panel') {
      slide.addShape(p.square ? pres.ShapeType.rect : pres.ShapeType.roundRect, { x: X(p.x), y: Y(p.y), w: p.w * u, h: p.h * u, rectRadius: (ill ? 0.16 : 0.1) * k,
        fill: { color: p.fill || 'FFFFFF' }, line: p.line ? { color: p.line, width: Math.max(0.75, (ill ? 1.75 : 1.25) * k) } : { type: 'none' } });
    } else if (p.t === 'cone') {
      const xs = p.pts.map((q) => q[0]), ys = p.pts.map((q) => q[1]), x0 = Math.min(...xs), y0 = Math.min(...ys);
      const pts = p.pts.map((q, i) => (i === 0 ? { x: (q[0] - x0) * u, y: (q[1] - y0) * u, moveTo: true } : { x: (q[0] - x0) * u, y: (q[1] - y0) * u }));
      pts.push({ close: true });
      slide.addShape(pres.ShapeType.custGeom, { x: X(x0), y: Y(y0), w: (Math.max(...xs) - x0) * u, h: (Math.max(...ys) - y0) * u,
        points: pts, fill: { color: p.fill, transparency: ill ? 45 : 35 }, line: { type: 'none' } });
    } else if (p.t === 'frame') {
      slide.addShape(ill ? pres.ShapeType.roundRect : pres.ShapeType.rect, { x: X(p.x), y: Y(p.y), w: p.w * u, h: p.h * u, rectRadius: 0.06 * k, fill: { type: 'none' },
        line: ill ? { color: ILL.ink, width: Math.max(0.75, 2 * k) } : { color: p.color, width: Math.max(0.75, 1.5 * k), dashType: 'dash' } });
    } else if (p.t === 'img') {
      ii++; const P = c.pal[p.tone] || c.pal.n, w = p.w * u, h = p.h * u;
      const file = c.files[p.name];
      if (file && fs.existsSync(file)) {
        if (p.accent && ill) {                                       // 결과 그림 뒤 옅은 원(강조)
          const r = 1.12; slide.addShape(pres.ShapeType.ellipse, { x: X(p.x) - w * (r - 1) / 2, y: Y(p.y) - h * (r - 1) / 2, w: w * r, h: h * r,
            fill: { color: P.tint }, line: { type: 'none' }, objectName: `halo ${ii}` });
        }
        const [iw, ih] = imgSize(file), sc = Math.min(w / iw, h / ih), dw = iw * sc, dh = ih * sc;
        slide.addImage({ path: file, x: X(p.x) + (w - dw) / 2, y: Y(p.y) + (h - dh) / 2, w: dw, h: dh, altText: p.name, objectName: `IMG ${ii} ${p.name}`.slice(0, 60) });
        continue;
      }
      const f = fitHint(p.name, w * 0.84, h * 0.78, BASE_PT.S * k * 0.8, Math.max(5, 9 * k));
      slide.addText(f.text, { shape: p.round ? pres.ShapeType.ellipse : pres.ShapeType.roundRect, rectRadius: 0.12 * k,
        x: X(p.x), y: Y(p.y), w, h, fill: { color: PH_FILL },
        line: p.accent ? { color: P.accent, width: Math.max(1, 2.25 * k) } : { color: PH_LINE, width: Math.max(0.5, 1 * k), dashType: 'dash' },
        fontFace: FONT, fontSize: f.pt, italic: true, color: MUTE, align: 'center', valign: 'middle', margin: 2,
        objectName: `IMG ${ii} ${p.name}`.slice(0, 60) });
    } else if (p.t === 'text') {
      const w = p.w * u, h = p.h * u, base = BASE_PT[p.size] * k;
      const f = fitPt(p.text, w, h, base, Math.min(base, MIN_PT * k), p.bold);
      if (!f.ok) warn.push(`${tag}: "${p.text}" 가 자리에 안 들어감 → 더 짧게`);
      slide.addText(p.text, { x: X(p.x), y: Y(p.y), w, h, fontFace: FONT, fontSize: f.pt, bold: !!p.bold, color: inkOf(p.color),
        align: p.align, valign: p.valign, margin: 0, isTextBox: true });
    } else if (p.t === 'chip') {
      const w = p.w * u, h = p.h * u, f = fitPt(p.text, w * 0.92, h * 0.86, BASE_PT.M * k, MIN_PT * k, true);
      if (!f.ok) warn.push(`${tag}: 결과 "${p.text}" 가 자리에 안 들어감 → 더 짧게`);
      slide.addText(p.text, { shape: pres.ShapeType.roundRect, rectRadius: 0.1 * k, x: X(p.x), y: Y(p.y), w, h,
        fill: p.soft ? { color: p.fill, transparency: 84 } : { color: p.fill },
        line: p.soft ? { color: p.fill, width: Math.max(0.75, 1.75 * k) } : { type: 'none' }, fontFace: FONT, fontSize: f.pt, bold: true,
        color: p.soft ? p.fill : 'FFFFFF', align: 'center', valign: 'middle', margin: 2 });
    } else if (p.t === 'arrow') {
      const x1 = X(p.x1), y1 = Y(p.y1), x2 = X(p.x2), y2 = Y(p.y2), col = ill && (!p.color || p.color === GRAY) ? ILL.arrow : p.color || GRAY;
      const line = { color: col, width: lw };
      if (p.kind === 'dashed') line.dashType = 'dash';
      if (p.kind !== 'inhibit') line.endArrowType = 'triangle';
      slide.addShape(pres.ShapeType.line, { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1), h: Math.abs(y2 - y1),
        flipH: x2 < x1, flipV: y2 < y1, line });
      if (p.kind === 'inhibit') {
        const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, nx = -dy / L, ny = dx / L, b = 1.6 * u;
        const ax = x2 + nx * b, ay = y2 + ny * b, bx = x2 - nx * b, by = y2 - ny * b;
        slide.addShape(pres.ShapeType.line, { x: Math.min(ax, bx), y: Math.min(ay, by), w: Math.abs(bx - ax), h: Math.abs(by - ay),
          flipH: bx < ax, flipV: by < ay, line: { color: col, width: lw * 1.3 } });
      }
    }
  }
}

function notesFor(opt, c, spec) {
  const uniq = [...new Set(c.images.map((i) => i.name))];
  const style = spec.image_style || STYLE_PREFIX;
  return [`${opt.id} · ${opt.layout}`, spec.paper && spec.paper.citation ? `Paper: ${spec.paper.citation}` : '', '',
    'Image slots and prompts:', ...uniq.map((n, i) => `${i + 1}. ${n} — ${style}, ${n}`), '',
    opt.left_out ? `Left out: ${opt.left_out}` : '', opt.boundary ? `Claim boundary: ${opt.boundary}` : '',
    'AI-generated images are for drafting only. Replace before submission and check the journal AI policy.'].filter((s) => s !== '').join('\n');
}

function validate(spec) {
  const err = [], warn = [];
  if (!spec.message) err.push('message(핵심 문장)가 없음');
  if (!Array.isArray(spec.options) || !spec.options.length) err.push('options 가 없음');
  (spec.options || []).forEach((o) => {
    if (!LAYOUTS[o.layout]) err.push(`${o.id}: layout 은 flow | compare | zoom | hub 중 하나`);
    const d = o.content || {};
    if (o.layout === 'flow' && !(d.steps && d.steps.length >= 3 && d.steps.length <= 6)) err.push(`${o.id}: flow 는 steps 3~6개`);
    if (o.layout === 'compare') {
      if (!(d.columns && d.columns.length >= 2 && d.columns.length <= 3)) err.push(`${o.id}: compare 는 columns 2~3개`);
      else if (new Set(d.columns.map((x) => (x.steps || []).length)).size > 1) err.push(`${o.id}: compare 는 모든 열의 steps 개수가 같아야 함 (같은 칸, 다른 곳만 다르게)`);
      else if (d.columns.some((x) => !x.steps || x.steps.length < 1 || x.steps.length > 3 || !x.outcome)) err.push(`${o.id}: compare 열마다 steps 1~3개와 outcome`);
    }
    if (o.layout === 'zoom' && !(d.levels && d.levels.length >= 1 && d.levels.length <= 3 && d.detail && d.detail.items && d.detail.items.length >= 2 && d.detail.items.length <= 4)) err.push(`${o.id}: zoom 은 levels 1~3개, detail.items 2~4개`);
    if (o.layout === 'hub' && !(d.center && ((d.inputs || []).length + (d.outputs || []).length) >= 2 && (d.inputs || []).length <= 3 && (d.outputs || []).length <= 3)) err.push(`${o.id}: hub 는 center 와 inputs/outputs 합쳐 2개 이상 (쪽마다 3개까지)`);
  });
  const ls = (spec.options || []).map((o) => o.layout);
  if (new Set(ls).size < ls.length) warn.push('같은 구도가 두 번 쓰임 → 시안끼리 구도가 달라야 고르는 의미가 있음');
  return { err, warn };
}

async function main() {
  const [specPath, outPath, flag, pick] = process.argv.slice(2);
  if (!specPath || !outPath) { console.error('usage: node build_ga_deck.js spec.json out.pptx [--final <id>]'); process.exit(2); }
  const spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));
  const v = validate(spec);
  if (v.err.length) { console.error('SPEC ERROR\n- ' + v.err.join('\n- ')); process.exit(1); }
  const lang = T[spec.lang] ? spec.lang : 'ko', L = T[lang], LN = LAYOUT_NAME[lang];
  const pal = JSON.parse(JSON.stringify(PALETTE));
  for (const key of Object.keys(spec.palette || {})) pal[key] = Object.assign(pal[key] || {}, spec.palette[key]);
  const aspect = spec.aspect || 1, warn = v.warn.slice(), summary = [];
  const pres = new PptxGenJS();
  pres.title = (spec.paper && spec.paper.title) || 'Graphical abstract draft';
  const built = spec.options.map((o) => ({ o, c: buildOption(o, spec, pal) }));
  built.forEach(({ o, c }) => {
    const nimg = new Set(c.images.map((i) => i.name)).size;
    if (c.wc > 30) warn.push(`${o.id}: 그림 안 글자 ${c.wc}단어 → 30단어 안쪽으로 줄이기`);
    if (nimg > 9) warn.push(`${o.id}: 요소 ${nimg}개 → 9개 안쪽으로 (한눈에 들어오는 수)`);
    summary.push({ id: o.id, layout: o.layout, images: [...new Set(c.images.map((i) => i.name))], words: c.wc });
  });

  if (flag === '--final') {
    const hit = built.find((b) => String(b.o.id).toLowerCase() === String(pick || '').toLowerCase());
    if (!hit) { console.error(`--final: 시안 "${pick}" 없음`); process.exit(1); }
    pres.defineLayout({ name: 'GA', width: 8 * aspect, height: 8 }); pres.layout = 'GA';
    const s = pres.addSlide(); s.background = { color: 'FFFFFF' };
    drawCanvas(pres, s, hit.c, 0, 0, 8, warn, hit.o.id); s.addNotes(notesFor(hit.o, hit.c, spec));
  } else {
    pres.layout = 'LAYOUT_WIDE';                                   // 13.333 × 7.5
    const SW = 13.333, cite = spec.paper && spec.paper.citation;
    // 1) 한눈에 보기
    const s1 = pres.addSlide(); s1.background = { color: 'FFFFFF' };
    s1.addText(`${L.title} ${built.length}`, { x: 0.5, y: 0.35, w: 5, h: 0.5, fontFace: FONT, fontSize: 22, bold: true, color: INK, margin: 0, isTextBox: true });
    if (cite) s1.addText(cite, { x: 5.6, y: 0.42, w: SW - 6.1, h: 0.36, fontFace: FONT, fontSize: 10.5, color: MUTE, align: 'right', margin: 0, isTextBox: true });
    const mf = fitPt(spec.message, SW - 1 - 1.5, 0.62, 14, 10.5, false);
    s1.addText([{ text: `${L.msg}  `, options: { bold: true, color: pal.a.accent } }, { text: spec.message, options: { color: INK } }],
      { x: 0.5, y: 0.95, w: SW - 1, h: 0.62, fontFace: FONT, fontSize: mf.pt, valign: 'top', margin: 0, isTextBox: true });
    const n = built.length, g = 0.4, colW = (SW - 1 - (n - 1) * g) / n, ch = Math.min(colW / aspect, 3.95), cw = ch * aspect, cy = 2.2;
    built.forEach(({ o, c }, i) => {
      const x0 = 0.5 + i * (colW + g), cx = x0 + (colW - cw) / 2;
      s1.addText(`${o.id} · ${o.name || LN[o.layout]}`, { x: x0, y: 1.72, w: colW, h: 0.38, fontFace: FONT, fontSize: 15, bold: true, color: INK, margin: 0, isTextBox: true });
      s1.addShape(pres.ShapeType.rect, { x: cx, y: cy, w: cw, h: ch, fill: { color: 'FFFFFF' }, line: { color: FRAME, width: 1 } });
      drawCanvas(pres, s1, c, cx, cy, ch, [], o.id);
      if (o.why) { const f = fitPt(o.why, colW, 0.66, 11.5, 9, false); s1.addText(o.why, { x: x0, y: cy + ch + 0.12, w: colW, h: 0.66, fontFace: FONT, fontSize: f.pt, color: GRAY, valign: 'top', margin: 0, isTextBox: true }); }
    });
    s1.addText(L.foot, { x: 0.5, y: 7.02, w: SW - 1, h: 0.3, fontFace: FONT, fontSize: 9.5, color: MUTE, margin: 0, isTextBox: true });
    // 2) 시안마다 1장: 왼쪽 캔버스 + 오른쪽 설명
    built.forEach(({ o, c }) => {
      const s = pres.addSlide(); s.background = { color: 'FFFFFF' };
      const wide = aspect > 1.3, ch2 = wide ? Math.min(3.6, (SW - 1) / aspect) : 6.5, cw2 = ch2 * aspect, cx = 0.5, cy2 = 0.5;
      s.addShape(pres.ShapeType.rect, { x: cx, y: cy2, w: cw2, h: ch2, fill: { color: 'FFFFFF' }, line: { color: FRAME, width: 1 } });
      drawCanvas(pres, s, c, cx, cy2, ch2, warn, o.id);
      const px = wide ? 0.5 : cx + cw2 + 0.45, py = wide ? cy2 + ch2 + 0.25 : 0.5, pw = wide ? SW - 1 : SW - 0.5 - px, phh = wide ? 7.5 - py - 0.3 : 6.5;
      const uniq = [...new Set(c.images.map((im) => im.name))];
      const runs = [], head = (t) => runs.push({ text: t, options: { bold: true, color: pal.a.accent, fontSize: wide ? 11 : 12, breakLine: true, paraSpaceBefore: wide ? 5 : 9 } });
      const body = (t) => runs.push({ text: t, options: { color: INK, fontSize: wide ? 11 : 12.5, breakLine: true } });
      runs.push({ text: `${L.opt} ${o.id} · ${o.name || LN[o.layout]}`, options: { bold: true, color: INK, fontSize: wide ? 17 : 22, breakLine: true } });
      if (o.why) { head(L.why); body(o.why); }
      head(`${L.imgs} ${uniq.length}`); body(uniq.map((nm, i) => `${i + 1}. ${nm}`).join(wide ? '   ' : '\n'));
      if (o.left_out) { head(L.left); body(o.left_out); }
      if (o.boundary) { head(L.bound); body(o.boundary); }
      s.addText(runs, { x: px, y: py, w: pw, h: phh, fontFace: FONT, valign: 'top', margin: 0, isTextBox: true });
      s.addNotes(notesFor(o, c, spec));
    });
  }
  await pres.writeFile({ fileName: outPath });
  try {                                                             // 폴더 항목 제거 (일부 클라우드 서비스에서 열기 오류)
    const JSZip = require(require.resolve('jszip', { paths: [require.resolve('pptxgenjs'), __dirname] })), z = await JSZip.loadAsync(fs.readFileSync(outPath));
    const z2 = new JSZip();
    for (const n of Object.keys(z.files)) { if (!z.files[n].dir) z2.file(n, await z.files[n].async('nodebuffer'), { createFolders: false }); }
    fs.writeFileSync(outPath, await z2.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));
  } catch (e) { /* jszip 이 없으면 그대로 둔다 */ }
  console.log(JSON.stringify({ out: outPath, mode: flag === '--final' ? 'final' : 'options', options: summary, warnings: [...new Set(warn)] }, null, 2));
}
main().catch((e) => { console.error(e); process.exit(1); });
