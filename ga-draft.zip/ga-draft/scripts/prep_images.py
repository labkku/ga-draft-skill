#!/usr/bin/env python3
"""prep_images.py — 생성 이미지를 PPT에 넣기 좋게 다듬는다.

    python3 prep_images.py <입력 폴더 또는 파일...> --out <출력 폴더> [--sheet 3x3 --names a,b,c,...]

- 흰 바탕(가장자리와 이어진 흰 부분)을 투명하게 바꾸고, 그림 둘레 여백을 잘라 낸다.
  그래야 색 면 패널 위에 그림이 테두리 없이 얹히고, 칸을 가득 채운다.
- --sheet RxC: 한 장에 여러 그림을 모아 만든 경우(예: 3x3) 흰 띠를 기준으로 잘라 나눈다.
  --names 로 왼쪽 위부터 차례로 파일 이름을 준다(PPT 그림 자리 이름과 같게).
"""
import argparse, os, sys
import numpy as np
from PIL import Image
try:
    from scipy import ndimage
except ImportError:      # scipy 가 없으면 numpy · Pillow 만으로 같은 결과를 낸다(조금 느림)
    ndimage = None

WHITE = 236      # 이보다 밝으면(세 채널 모두) 바탕 후보
EDGE = 3         # 가장자리 부드럽게 할 폭(px)


def runs(profile, min_len=20):
    out, s = [], None
    for i, v in enumerate(profile):
        if v and s is None:
            s = i
        if not v and s is not None:
            out.append((s, i)); s = None
    if s is not None:
        out.append((s, len(profile)))
    return [r for r in out if r[1] - r[0] >= min_len]


def split_sheet(im, rows, cols):
    a = np.asarray(im.convert('RGB')).astype(int)
    ink = a.min(axis=2) < WHITE
    tiles = []
    rr = runs(ink.sum(axis=1) > 3)
    if len(rr) != rows:
        sys.exit(f'가로 띠를 {rows}개로 못 나눔(찾은 수 {len(rr)}). 그림 사이 흰 여백을 확인하세요')
    for y0, y1 in rr:
        cc = runs(ink[y0:y1].sum(axis=0) > 3)
        if len(cc) != cols:
            sys.exit(f'세로 칸을 {cols}개로 못 나눔(찾은 수 {len(cc)})')
        for x0, x1 in cc:
            tiles.append(im.crop((max(0, x0 - 8), max(0, y0 - 8), min(im.width, x1 + 8), min(im.height, y1 + 8))))
    return tiles


def border_bg(cand):
    """바탕 후보 가운데 그림 가장자리와 이어진 부분만 고른다."""
    if ndimage is not None:
        lab, _ = ndimage.label(cand)
        border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
        return np.isin(lab, list(border))
    bg = np.zeros_like(cand)                      # 가장자리의 바탕 후보에서 시작해, 바탕 후보를 따라 번져 들어간다
    bg[0], bg[-1], bg[:, 0], bg[:, -1] = cand[0], cand[-1], cand[:, 0], cand[:, -1]
    while True:
        nxt = grow(bg, 1) & cand
        if (nxt == bg).all():
            return bg
        bg = nxt


def grow(mask, n):
    """mask 를 n픽셀 넓힌다(상하좌우)."""
    if ndimage is not None:
        return ndimage.binary_dilation(mask, iterations=n)
    out = mask.copy()
    for _ in range(n):
        p = np.pad(out, 1)
        out = p[1:-1, 1:-1] | p[:-2, 1:-1] | p[2:, 1:-1] | p[1:-1, :-2] | p[1:-1, 2:]
    return out


def cutout(im):
    rgb = np.asarray(im.convert('RGB')).astype(np.int16)
    mn = rgb.min(axis=2)
    cand = mn >= WHITE
    bg = border_bg(cand)
    alpha = np.where(bg, 0, 255).astype(np.float32)
    band = grow(bg, EDGE) & ~bg
    soft = np.clip((255 - mn) / (255 - 200), 0, 1) * 255
    alpha[band] = np.minimum(alpha[band], soft[band])
    rgba = np.dstack([rgb.astype(np.uint8), alpha.astype(np.uint8)])
    out = Image.fromarray(rgba, 'RGBA')
    box = out.getchannel('A').point(lambda v: 255 if v > 20 else 0).getbbox()
    if box:
        pad = 6
        out = out.crop((max(0, box[0] - pad), max(0, box[1] - pad), min(out.width, box[2] + pad), min(out.height, box[3] + pad)))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('inputs', nargs='+')
    ap.add_argument('--out', required=True)
    ap.add_argument('--sheet')
    ap.add_argument('--names')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    jobs = []
    if a.sheet:
        r, c = map(int, a.sheet.lower().split('x'))
        names = [n.strip() for n in (a.names or '').split(',') if n.strip()]
        tiles = split_sheet(Image.open(a.inputs[0]), r, c)
        if names and len(names) != len(tiles):
            sys.exit(f'--names {len(names)}개, 그림 {len(tiles)}개: 개수를 맞추세요')
        jobs = [(names[i] if names else f'img_{i + 1}', t) for i, t in enumerate(tiles)]
    else:
        files = []
        for p in a.inputs:
            files += [os.path.join(p, f) for f in sorted(os.listdir(p))] if os.path.isdir(p) else [p]
        jobs = [(os.path.splitext(os.path.basename(f))[0], Image.open(f)) for f in files if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
    for name, im in jobs:
        o = cutout(im)
        path = os.path.join(a.out, name + '.png')
        o.save(path)
        print(f'{path}  {o.width}x{o.height}')


if __name__ == '__main__':
    main()
