---
name: ga-draft
description: 논문 내용으로 Figure 초안(요약 그림 · 도식 · Graphical abstract)을 구도가 다른 시안 3개의 PPT로 만든다. 논문 Figure · GA · 요약 그림의 초안이나 시안이 필요하거나 레퍼런스 GA처럼 만들어 달라고 하면 반드시 이 스킬을 쓴다. 그래프 같은 데이터 Figure는 대상이 아니다.
---

# Figure 초안 3단계: 핵심 문장 확인 → 시안 세 개 → 그림 넣기

이 스킬이 만드는 Figure는 논문의 요점 하나를 한 장으로 보여 주는 도식이다(요약 그림, 모식도, Graphical abstract = GA). 그래프 같은 데이터 Figure는 만들지 않는다. 처음 만드는 사람이 가장 오래 헤매는 곳은 그림 솜씨가 아니라 **구도**(무엇을 어디에 둘지)다. 그래서 이 스킬은 그림을 그리기 전에 구도가 서로 다른 시안 3개를 PPT로 먼저 보여 주고, 사람이 하나를 고른 뒤에 그 시안에 필요한 그림만 채운다. 고르기 전에 그림부터 만들면 버릴 시안의 그림까지 만들게 되고, 따로 만든 그림끼리 화풍도 어긋난다.

결과물은 **초안**이다. 투고본은 사람이 다듬고, 그림은 저널 규정에 맞는 것으로 바꾼다(아래 "저널 규정").

## 진행 순서 (3단계)

사용자에게는 아래 세 단계를 "1단계 · 2단계 · 3단계"라고 부르고, 단계가 바뀔 때 지금 몇 단계인지 한마디로 알려 준다.

### 1단계. 핵심 문장 확인 (여기서 틀리면 시안 3장이 다 틀린다)

받을 것: 이미지로 만들 논문 내용. 초록이나 결과 요약에 주요 결과 몇 줄(Figure 제목이면 충분)이면 된다. 원고 전체는 필요 없다. 미공개 원고라면 초록과 결과 요약만 받아도 된다고 알려 준다.

아래 표를 채워 보여 주고, 도식화할 핵심 문장이 맞는지 확인을 받은 뒤에 2단계로 간다. 줄기가 안 잡힐 만큼 정보가 부족하면 시안을 만들지 말고 무엇이 빠졌는지 먼저 묻는다. 빈칸을 그럴듯한 내용으로 메우지 않는다.

| 항목 | 내용 |
|---|---|
| 핵심 문장 | 도식화할 한 문장. "누가/무엇이 → 무엇을 해서 → 어떤 결과" |
| 줄기 | 문제(또는 출발 상태) → 개입·방법 → 주 결과 → 의미. 3~5마디 |
| 생물학적 맥락 | 종 · 성별 · 조직/세포 · 모델 (받은 내용에 적힌 만큼만) |
| 근거 수준 | 마디마다 인과(조작 실험)인지 연관(관찰)인지 |
| 뺄 것 | 보조 결과, 하위 분석, 방법 세부. 왜 빼는지 한 줄 |

#### 레퍼런스 GA 읽기 (있으면 1단계에서 함께)

사용자가 GA 이미지를 첨부했거나(목표 저널의 최근 GA, 좋아하는 GA) 프로젝트 지식에 GA가 들어 있으면, `references/patterns.md`의 "패턴 카드" 양식으로 한 장씩 읽고 공통점을 3~5줄로 정리한다. 그 공통점(주로 쓰는 구도, 요소 수, 글자 양, 색 쓰임, 맥락 표시 방식)을 시안에 반영하고, 시안 하나는 레퍼런스에서 가장 많이 나온 구도로 만든다.

레퍼런스에서 가져오는 것은 **구도 패턴**뿐이다. 그림이나 문구를 옮기지 않는다. 레퍼런스가 없으면 `references/patterns.md`의 내장 패턴(실제 저널 GA 분석)을 쓴다.

### 2단계. 시안 세 개 만들기

**구도 고르기.** 논문의 논리에 맞는 구도 3개를 고른다. 세 시안은 구도가 서로 달라야 한다(같은 구도에 글자만 바꾼 것은 시안이 아니다). 맞지 않는 구도를 억지로 쓰지 말고, 4개 중 맞는 3개를 고른 이유를 시안마다 `why`에 적는다.

| 구도 (`layout`) | 맞는 논문 | 배치 |
|---|---|---|
| 한 줄 흐름 `flow` | 원인 → 과정 → 결과가 한 줄로 이어짐. 방법 파이프라인 | 3~6마디를 화살표로. 마지막 마디가 결과 |
| 나란히 비교 `compare` | 핵심 결과가 "차이"다. WT vs KO, 처리 전후, 정상 vs 질환 | 같은 칸을 2~3열로 나란히, 다른 곳만 다르게. 열마다 결과 상자 |
| 확대 `zoom` | 개체 → 조직 → 세포·분자로 내려가는 기전. "어디서"가 중요 | 위 한 줄은 현상, 아래 큰 상자는 확대한 기전 |
| 가운데형 `hub` | 한 인자가 여러 결과로 갈라지거나 여러 입력이 한 곳에 모임 | 가운데 주인공, 왼쪽 입력, 오른쪽 결과 |

**spec 쓰기.** 아래 "spec 형식"대로 JSON을 쓴다. 그림 안 글자는 투고 언어(기본 영어), `why` · `left_out` · `boundary`는 사용자의 언어로 쓴다.

**만들기.**

```bash
node <이 스킬 폴더>/scripts/build_ga_deck.js spec.json ga_options.pptx
```

`pptxgenjs`가 없다는 오류가 나면 `npm install pptxgenjs` 뒤에 다시 실행한다. 출력의 `warnings`는 그대로 두지 않는다. 대부분 글자가 자리에 안 들어간다는 뜻이고, 글자를 줄이는 것이 답이다(글씨를 작게 만드는 것은 답이 아니다. GA는 목차에서 엄지손톱 크기로 보인다).

가능하면 PPT를 이미지로 바꿔 직접 본다(글자 넘침, 겹침, 읽는 순서). 그다음 파일을 주고 이렇게만 말한다: 시안 3개가 각각 무엇을 앞세우는지 한 줄씩, 그리고 추천 하나와 이유. 덱 1쪽은 세 시안을 나란히 둔 "한눈에 보기", 2~4쪽은 시안마다 큰 캔버스와 설명(왜 이 구도 · 그림 자리 · 뺀 것 · 주의)이다. 그림 자리는 회색 칸으로 비어 있다.

### 3단계. 하나 고르면: 그림 목록과 프롬프트 → 그림 넣기

사용자가 하나를 고르면(수정 요청이 있으면 spec을 고쳐서):

```bash
node <이 스킬 폴더>/scripts/build_ga_deck.js spec.json ga_final.pptx --final B
```

캔버스만 있는 작업 파일이 나온다. 함께 **그림 목록**을 준다. 그림 자리마다 이름, 무엇을 그리는지, 프롬프트 한 줄. 프롬프트는 모두 같은 화풍 문장으로 시작해 한 세트로 보이게 한다:

> flat vector scientific illustration, simple shapes, clean outlines, soft muted colors, pure white background, single subject centered, no text, no labels, no arrows, + [그릴 대상]

글자와 화살표는 그림에 넣지 않는다(PPT에서 고칠 수 있어야 하고, 생성 이미지 속 글자는 자주 틀린다). 이 대화에서 이미지를 만들 수 없으면 프롬프트만 주고, 사용자가 쓰는 이미지 도구에 붙여 넣게 한다.

그리고 이 한 줄을 꼭 붙인다: **이렇게 생성한 이미지는 초안용이다. 투고 전에는 저널 규정(AI 정책)을 확인하고, 규정에 맞는 그림(직접 그린 것이나 라이선스가 분명한 아이콘)으로 바꾼다.** 무료 아이콘 출처는 아래 "저널 규정"에 있다.

#### 그림 넣기 (사용자가 그림을 올리면)

먼저 흰 바탕을 투명하게 하고 여백을 잘라 낸다. 그래야 그림이 테두리 없이 색 면 위에 얹히고 칸을 가득 채운다.

```bash
python3 <이 스킬 폴더>/scripts/prep_images.py <그림 폴더 또는 파일> --out img_cut
# 여러 그림을 한 장(예: 3×3)에 모아 만들었다면:
python3 <이 스킬 폴더>/scripts/prep_images.py sheet.png --sheet 3x3 --out img_cut --names "그림 자리 1,그림 자리 2,..."
```

`numpy`나 `Pillow`가 없다는 오류가 나면 `pip install numpy pillow` 뒤에 다시 실행한다(`scipy`는 없어도 된다).

그다음 spec의 `image_files`에 `"그림 자리 이름": "img_cut/파일.png"`로 적고 2단계나 3단계의 명령을 다시 실행하면 그 자리에 그림이 들어간다. 아직 없는 자리는 회색 칸으로 남는다. 회색 칸이 다 차면 초안 완성이다. 사용자가 PowerPoint에서 회색 칸 자리에 그림을 직접 넣어도 된다.

그림을 넣은 뒤 꼭 직접 본다. 생성 이미지는 생물학적으로 틀린 그림을 자주 만든다(생쥐 뇌에 사람처럼 주름, 다리 개수, 세포 소기관 위치). 틀린 그림은 무엇이 틀렸는지와 고칠 프롬프트를 알려 준다.

## 그림 안 규칙 (시안을 쓸 때 지킬 것)

실제 저널 GA와 GA 디자인 연구에서 반복해서 나온 것들이다. 이유를 알고 쓰면 예외도 판단할 수 있다.

- **요점은 하나.** 결과를 다 넣으면 아무것도 안 읽힌다. 보조 결과는 `left_out`으로 보낸다.
- **시작과 끝이 보이게.** 왼쪽→오른쪽 또는 위→아래. 마지막 마디는 결과(행동, 표현형, 임상적 의미)로 끝낸다.
- **요소는 한 시안에 9개 안쪽**, 그림 안 글자는 **30단어 안쪽**(잘 만든 GA는 15단어 안팎). 이름표는 명사구 1~3단어. 문장을 쓰지 않는다.
- **화살표는 뜻이 하나.** 일반 화살표 = "~로 이어진다(인과)". 억제는 `-|`, 연관만 확인된 관계는 `~`(점선). 뜻이 헷갈리면 화살표 위에 동사 한두 단어.
- **비교는 같은 칸을 두 번.** 두 열의 칸 수와 순서를 맞추고 다른 칸만 `diff`로 굵게. 그래야 차이가 먼저 보인다.
- **색은 두 가지 + 회색.** 같은 색은 같은 뜻(파랑 = 개입·정상, 주황빨강 = 질환·대조). 빨강–초록 조합은 색각 이상에서 구분이 안 되니 쓰지 않는다.
- **생물학적 맥락을 남긴다.** 종 · 성별 · 조직을 아래 한 줄(`context`)이나 그림 자리로. 맥락이 없으면 다른 분야 독자가 못 읽는다.
- **데이터는 넣지 않는다.** 그래프, 수치, p값은 본문 Figure의 몫이다(Cell Press는 GA에 데이터 항목을 금지한다).
- **그림 자리 이름은 3~5단어**로, 무엇을 그릴지 바로 알 수 있게(`leaky brain vessel`).

## 과장 금지 (그림이 논문보다 센 주장을 하면 안 된다)

깔끔한 그림은 실제 근거보다 확실해 보인다. 그래서 시안마다 `boundary`에 "이 그림이 말하면 안 되는 것"을 한 줄 적는다.

- 연관을 실선 화살표로 그리지 않는다. 관찰 연구의 관계는 `~` 점선.
- 생쥐 결과를 사람 그림으로 그리지 않는다. 사람 데이터가 연관뿐이면 빼거나 점선으로.
- 논문이 보이지 않은 중간 단계, 세포 종류, 기전을 채워 넣지 않는다.
- 추측(논의에만 있는 내용)은 빼거나, 넣는다면 점선으로 구분한다.
- 받은 논문 내용에 없는 숫자, 세포주, 조직 이름을 지어내지 않는다.

## 저널 규정 (2026년 11월 기준, 바뀔 수 있으니 투고 전 원문 확인)

- Cell Press: 1200 × 1200px(300dpi) 정사각, Arial 8~12pt, 한 가지 요점, 데이터 항목 금지. **범용 생성 AI 도구로 GA를 만들면 안 된다**(BioRender 같은 전용 과학 일러스트 도구 안의 생성 AI는 허용).
- Elsevier 저널도 같은 방침, Springer Nature 저널은 생성 AI 이미지를 원칙적으로 싣지 않는다.
- 그래서 이 스킬의 결과는 초안이고, 생성한 이미지는 초안용이다. 사용자가 목표 저널을 말하면 크기와 정책을 그 저널의 Guide for Authors 원문에서 확인해 알려 주고(웹 검색을 쓸 수 있으면 직접 찾는다), 가로형 저널이면 spec의 `aspect`를 바꾼다.
- 투고본 그림은 직접 그리거나 BioRender 같은 전용 도구, 또는 라이선스가 분명한 무료 아이콘으로 바꾼다: Servier Medical Art(smart.servier.com, CC BY 4.0 · 출처 표기) · Bioicons(bioicons.com, 아이콘마다 라이선스 확인) · NIH BioArt(bioart.niaid.nih.gov). 한 출처에서 고르면 화풍이 맞는다.
- 내보내기: PPT에서 PDF로 저장하면 크기를 바꿔도 깨지지 않는다. PNG · JPG는 1200px 이상으로.

## spec 형식

```json
{
  "lang": "ko",
  "paper": { "title": "논문 제목", "citation": "Kim et al., Journal 2026 · doi:..." },
  "message": "핵심 문장 (1단계에서 확인받은 것)",
  "context": "Male mice · hippocampus",
  "aspect": 1,
  "options": [
    { "id": "A", "layout": "flow",
      "why": "왜 이 구도인지 한두 문장",
      "left_out": "뺀 것", "boundary": "이 그림이 말하면 안 되는 것",
      "content": {
        "steps": [ { "label": "Exercise", "image": "mouse on running wheel" },
                   { "label": "Factor X ↑", "image": "muscle fiber releasing protein" },
                   { "label": "Better memory", "image": "mouse in maze" } ],
        "links": [ "releases", "~ linked to" ] } },
    { "id": "B", "layout": "compare",
      "content": {
        "shared": { "label": "Chronic stress", "image": "stressed mouse" },
        "columns": [
          { "title": "Control", "tone": "b",
            "steps": [ { "label": "Barrier leaky", "image": "leaky brain vessel" } ], "outcome": "Social avoidance" },
          { "title": "Exercise", "tone": "a",
            "steps": [ { "label": "Barrier intact", "image": "sealed brain vessel", "diff": true } ], "outcome": "Resilience" } ] } },
    { "id": "C", "layout": "zoom",
      "content": {
        "levels": [ { "label": "Exercised mouse", "image": "mouse on running wheel" },
                    { "label": "Hippocampus", "image": "mouse brain hippocampus" } ],
        "outcome": { "label": "Better memory", "image": "mouse in maze" },
        "detail": { "title": "Inside the hippocampus",
          "items": [ { "label": "Factor X arrives", "image": "protein crossing vessel wall" },
                     { "label": "BDNF ↑", "image": "neuron with growth factor" },
                     { "label": "New neurons", "image": "newborn neurons" } ],
          "links": [ "", "" ] } } }
  ]
}
```

- `flow`: `steps` 3~6개, `links`는 마디 사이(개수 = steps − 1). `headline`(선택)은 위 제목 한 줄. 정사각 캔버스에서 4마디부터는 그림을 크게 쓰려고 두 줄(U자)로 놓인다.
- `compare`: `columns` 2~3개, 열마다 `steps` 1~3개(모든 열이 같은 개수)와 `outcome`. `tone`은 `a`(파랑) · `b`(주황빨강) · `n`(회색). `shared`(선택)는 두 열의 공통 출발점.
- `zoom`: `levels` 1~3개(마지막 것이 확대되는 곳), `outcome`(선택), `detail.items` 2~4개. `top_links`(선택)는 윗줄 화살표.
- `hub`: `center`, `inputs` 0~3개, `outputs` 0~3개. 항목의 `link`로 화살표 종류와 글자.
- 링크 글자: `"raises"` 일반 · `"-| blocks"` 억제 · `"~ linked to"` 점선(연관) · `""` 글자 없음.
- `aspect`: 가로 ÷ 세로. 1 = 정사각(Cell Press), 가로형 저널은 2 안팎.
- `image_files`(선택): `{ "그림 자리 이름": "파일 경로" }`.
- `style`(선택): `illustrated`(기본: 그림이 주인공, 테두리 없는 그림 · 맞닿은 색 면 패널 · 굵은 남색 화살표 · 결과 그림 뒤 옅은 원) 또는 `clean`(선 위주).
- `palette`(선택): `{ "a": { "accent": "1F5FA8", "tint": "E4EEF9" } }` 처럼 색 바꾸기.

## 출처

Cell Press Graphical Abstract Guidelines · Jambor & Bornhäuser, "Ten simple rules for designing graphical abstracts", PLOS Comput Biol 2024 (CC BY 4.0) · Hullman & Bach, "Picturing Science: Design Patterns in Graphical Abstracts", 2018 · 과장 금지 규칙은 aipoch/medical-research-skills `graphical-abstract-generator`(MIT)의 규칙을 줄여 옮김.
